/*
 * led.h
 *
 * Created: 2015-11-04 오후 2:38:17
 *  Author: mksong
 */

void led_init(void);
